import React from 'react';
import UsePromiseSample from './UsePromiseSample';

const App = () => {
  return <UsePromiseSample />;
};

export default App;